# Issue

What Github issue is this PR targeting?

## Tasklist

 - [ ] ADD OWN TASKS HERE
 - [ ] Add changelog entry
 - [ ] Test with osrm-frontend (?)
 - [ ] Review

## Requirements / Relations

 Link any requirements here. Other pull requests this PR is based on?
