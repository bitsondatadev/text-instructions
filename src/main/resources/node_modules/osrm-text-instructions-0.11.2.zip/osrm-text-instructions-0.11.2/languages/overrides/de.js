module.exports = function(content) {
    content.meta.capitalizeFirstLetter = true;

    return content;
};
